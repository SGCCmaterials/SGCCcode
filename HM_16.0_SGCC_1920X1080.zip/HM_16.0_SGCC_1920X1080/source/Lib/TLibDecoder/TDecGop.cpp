/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TDecGop.cpp
    \brief    GOP decoder class
*/

#include "TDecGop.h"
#include "TDecCAVLC.h"
#include "TDecSbac.h"
#include "TDecBinCoder.h"
#include "TDecBinCoderCABAC.h"
#include "libmd5/MD5.h"
#include "TLibCommon/SEI.h"
#include "TLibCommon/TComDataCU.h"
#include <time.h>
#include "TDecCu.h"
#include "math.h" 
#include <algorithm>
#include <fstream>
#include "windows.h"
extern Bool g_md5_mismatch; ///< top level flag to signal when there is a decode problem
extern UInt target;
extern UInt numm;
UInt QP, cc;
UInt N3, N2, N1;
float b, a;
char filename[1315];
UInt table_N3_22[9] = {9,15,21,27,40,59,80,226,371};
UInt table_N2_22[9] = {62,100,139,179,260,386,510,510,510};
UInt table_N1_22[9] = {158,259,359,459,510,510,510,510,510};

UInt table_N3_27[15] = {7,11,15,19,23,27,33,46,59,72,136,234,332,430,510};
UInt table_N2_27[15] = {47,73,100,126,152,179,221,306,391,476,510,510,510,510,510};
UInt table_N1_27[15] = {121,189,256,324,392,459,510,510,510,510,510,510,510,510,510};

UInt table_N3_32[19] = {5,8,11,14,18,21,24,27,30,40,50,60,70,101,178,254,331,408,484};
UInt table_N2_32[19] = {33,54,74,95,116,136,157,177,198,264,331,398,464,510,510,510,510,510,510};
UInt table_N1_32[19] = {86,139,192,245,297,350,403,457,510,510,510,510,510,510,510,510,510,510,510};

UInt table_N3_37[24] = {4,6,9,12,14,17,19,22,25,27,30,38,47,55,64,72,102,167,231,295,360,424,489,510};
UInt table_N2_37[24] = {25,42,59,76,94,111,128,146,163,180,198,252,308,364,419,476,510,510,510,510,510,510,510,510};
UInt table_N1_37[24] = {63,108,153,197,242,286,331,375,419,464,508,510,510,510,510,510,510,510,510,510,510,510,510,510};


float w[510] = {0.039964,0.089918,0.139873,0.188011,0.235241,0.280654,0.324251,0.366031,0.404178,0.438692,0.470481,0.495913,0.516803,0.531335,0.537693,0.537693,0.531335,0.516803,0.495913,0.470481,0.438692,0.404178,0.366031,0.324251,0.280654,0.235241,0.188011,0.139873,0.089918,0.039964,0.066303,0.118074,0.169846,0.219800,0.268847,0.316985,0.362398,0.406903,0.447775,0.485922,0.519528,0.548592,0.572207,0.587648,0.595822,0.595822,0.587648,0.572207,0.548592,0.519528,0.485922,0.447775,0.406903,0.362398,0.316985,0.268847,0.219800,0.169846,0.118074,0.066303,0.089918,0.143506,0.196185,0.247956,0.298819,0.349682,0.397820,0.444142,0.488647,0.530427,0.567666,0.599455,0.625795,0.644868,0.653951,0.653951,0.644868,0.625795,0.599455,0.567666,0.530427,0.488647,0.444142,0.397820,0.349682,0.298819,0.247956,0.196185,0.143506,0.089918,0.109900,0.165304,0.218892,0.273388,0.326067,0.377838,0.428701,0.478656,0.525886,0.570391,0.612171,0.648501,0.678474,0.700272,0.712080,0.712080,0.700272,0.678474,0.648501,0.612171,0.570391,0.525886,0.478656,0.428701,0.377838,0.326067,0.273388,0.218892,0.165304,0.109900,0.127157,0.182561,0.238874,0.294278,0.348774,0.402361,0.455949,0.507720,0.558583,0.607629,0.653043,0.693915,0.729337,0.755677,0.769301,0.769301,0.755677,0.729337,0.693915,0.653043,0.607629,0.558583,0.507720,0.455949,0.402361,0.348774,0.294278,0.238874,0.182561,0.127157,0.140781,0.197094,0.254314,0.310627,0.366939,0.422343,0.477748,0.532243,0.585831,0.637602,0.688465,0.734787,0.776567,0.808356,0.827430,0.827430,0.808356,0.776567,0.734787,0.688465,0.637602,0.585831,0.532243,0.477748,0.422343,0.366939,0.310627,0.254314,0.197094,0.140781,0.149864,0.207993,0.265213,0.322434,0.379655,0.436876,0.494096,0.550409,0.605813,0.661217,0.715713,0.767484,0.816530,0.858311,0.883742,0.883742,0.858311,0.816530,0.767484,0.715713,0.661217,0.605813,0.550409,0.494096,0.436876,0.379655,0.322434,0.265213,0.207993,0.149864,0.156222,0.213442,0.271571,0.329700,0.387829,0.445958,0.503179,0.561308,0.618529,0.675749,0.732970,0.790191,0.845595,0.897366,0.938238,0.938238,0.897366,0.845595,0.790191,0.732970,0.675749,0.618529,0.561308,0.503179,0.445958,0.387829,0.329700,0.271571,0.213442,0.156222,0.157130,0.215259,0.273388,0.331517,0.389646,0.447775,0.505904,0.564033,0.622162,0.680291,0.738420,0.796549,0.854678,0.912807,0.970936,0.970936,0.912807,0.854678,0.796549,0.738420,0.680291,0.622162,0.564033,0.505904,0.447775,0.389646,0.331517,0.273388,0.215259,0.157130,0.155313,0.213442,0.271571,0.328792,0.386921,0.445050,0.502271,0.560400,0.617620,0.674841,0.732062,0.787466,0.842870,0.893733,0.931880,0.931880,0.893733,0.842870,0.787466,0.732062,0.674841,0.617620,0.560400,0.502271,0.445050,0.386921,0.328792,0.271571,0.213442,0.155313,0.148955,0.206176,0.264305,0.321526,0.378747,0.435059,0.492280,0.548592,0.603996,0.659401,0.712988,0.763851,0.811989,0.851953,0.877384,0.877384,0.851953,0.811989,0.763851,0.712988,0.659401,0.603996,0.548592,0.492280,0.435059,0.378747,0.321526,0.264305,0.206176,0.148955,0.138965,0.196185,0.252498,0.308810,0.364214,0.420527,0.475023,0.529519,0.583106,0.634877,0.683924,0.730245,0.770209,0.801998,0.820163,0.820163,0.801998,0.770209,0.730245,0.683924,0.634877,0.583106,0.529519,0.475023,0.420527,0.364214,0.308810,0.252498,0.196185,0.138965,0.125341,0.180745,0.236149,0.291553,0.346049,0.399637,0.453224,0.504995,0.554950,0.603088,0.647593,0.688465,0.722979,0.748411,0.762943,0.762943,0.748411,0.722979,0.688465,0.647593,0.603088,0.554950,0.504995,0.453224,0.399637,0.346049,0.291553,0.236149,0.180745,0.125341,0.108084,0.162579,0.216167,0.269755,0.322434,0.375114,0.425068,0.474114,0.521344,0.565849,0.606721,0.643052,0.672116,0.693915,0.704814,0.704814,0.693915,0.672116,0.643052,0.606721,0.565849,0.521344,0.474114,0.425068,0.375114,0.322434,0.269755,0.216167,0.162579,0.108084,0.087193,0.139873,0.192552,0.244323,0.296094,0.345141,0.393279,0.439600,0.484105,0.524977,0.561308,0.593097,0.619437,0.637602,0.646685,0.646685,0.637602,0.619437,0.593097,0.561308,0.524977,0.484105,0.439600,0.393279,0.345141,0.296094,0.244323,0.192552,0.139873,0.087193,0.062670,0.114441,0.166213,0.216167,0.265213,0.312443,0.357856,0.401453,0.442325,0.480472,0.514078,0.542234,0.564941,0.580381,0.588556,0.588556,0.580381,0.564941,0.542234,0.514078,0.480472,0.442325,0.401453,0.357856,0.312443,0.265213,0.216167,0.166213,0.114441,0.062670,0.038147,0.088102,0.138056,0.186194,0.233424,0.278837,0.321526,0.363306,0.401453,0.435967,0.466848,0.493188,0.513170,0.527702,0.534968,0.534968,0.527702,0.513170,0.493188,0.466848,0.435967,0.401453,0.363306,0.321526,0.278837,0.233424,0.186194,0.138056,0.088102,0.038147};

float TDecCu::ctr[TDecCu::frames][19][32] = {0};
float TDecCu::ctr2[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::ctrr[TDecCu::frames][TDecCu::LCUs][32] = {0};
float TDecCu::ww[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::www[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::wwww[TDecCu::frames][TDecCu::LCUs] = {0};
//! \ingroup TLibDecoder
//! \{
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI);
// ====================================================================================================================
// Constructor / destructor / initialization / destroy
// ====================================================================================================================

TDecGop::TDecGop()
{
  m_dDecTime = 0;
  m_pcSbacDecoders = NULL;
  m_pcBinCABACs = NULL;
}

TDecGop::~TDecGop()
{

}

Void TDecGop::create()
{

}


Void TDecGop::destroy()
{
}

Void TDecGop::init( TDecEntropy*            pcEntropyDecoder,
                   TDecSbac*               pcSbacDecoder,
                   TDecBinCABAC*           pcBinCABAC,
                   TDecCavlc*              pcCavlcDecoder,
                   TDecSlice*              pcSliceDecoder,
                   TComLoopFilter*         pcLoopFilter,
                   TComSampleAdaptiveOffset* pcSAO
                   )
{
  m_pcEntropyDecoder      = pcEntropyDecoder;
  m_pcSbacDecoder         = pcSbacDecoder;
  m_pcBinCABAC            = pcBinCABAC;
  m_pcCavlcDecoder        = pcCavlcDecoder;
  m_pcSliceDecoder        = pcSliceDecoder;
  m_pcLoopFilter          = pcLoopFilter;
  m_pcSAO  = pcSAO;
}


// ====================================================================================================================
// Private member functions
// ====================================================================================================================
// ====================================================================================================================
// Public member functions
// ====================================================================================================================

Void TDecGop::decompressSlice(TComInputBitstream* pcBitstream, TComPic*& rpcPic)
{

  TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());

  UInt QP_o = pcSlice->getSliceQp();

  if(QP_o < 27) QP = 22;
  else if ( QP_o >= 27 && QP_o < 32) QP = 27;
  else if ( QP_o >= 32 && QP_o < 36) QP = 32;
  else if ( QP_o >= 37) QP = 37;

  if(QP == 22) { a = 0.3041, b = 0.0255;}
  if(QP == 27) { a = 0.3874, b = 0.0433;}
  if(QP == 32) { a = 0.4101, b = 0.0459;}
  if(QP == 37) { a = 0.4347, b = 0.0576;}

   if(QP ==22)
  {
     if(target>=15 && target<=23)
	 {
		 N3 = table_N3_22[target-15]; N2 = table_N2_22[target-15]; N1 = table_N1_22[target-15];
	 } 
	 else if(target > 23)
     {
		 N3 = table_N3_22[8]; N2 = table_N2_22[8]; N1 = table_N1_22[8];
	 }
  }

  if(QP ==27)
  {
     if(target>=16 && target<=30)
	 {
		 N3 = table_N3_27[target-16]; N2 = table_N2_27[target-16]; N1 = table_N1_27[target-16];
	 } 
	 else if(target>=30)
	 {
		 N3 = table_N3_27[14]; N2 = table_N2_27[14]; N1 = table_N1_27[14];
	 } 
  }

  if(QP ==32)
  {
     if(target>=17 && target <= 35)
	 {
		 N3 = table_N3_32[target-17]; N2 = table_N2_32[target-17]; N1 = table_N1_32[target-17];
	 } 
	 else if(target>=35)
	 {
		 N3 = table_N3_32[18]; N2 = table_N2_32[18]; N1 = table_N1_32[18];
	 } 
  }

  if(QP ==37)
  {
     if(target>=17 && target<=40)
	 {
		 N3 = table_N3_37[target-17]; N2 = table_N2_37[target-17]; N1 = table_N1_37[target-17];
	 } 
	 else if(target>=40)
	 {
		 N3 = table_N3_37[23]; N2 = table_N2_37[23]; N1 = table_N1_37[23];
	 } 
  }


  // Table of extracted substreams.
  // These must be deallocated AND their internal fifos, too.
  TComInputBitstream **ppcSubstreams = NULL;
  TDecCu::uiPoc = pcSlice->getPOC();//yangren begin
  //-- For time output for each slice
//  clock_t iBeforeTime = clock();
  m_pcSbacDecoder->init( (TDecBinIf*)m_pcBinCABAC );
  m_pcEntropyDecoder->setEntropyDecoder (m_pcSbacDecoder);

  UInt uiNumSubstreams = pcSlice->getPPS()->getEntropyCodingSyncEnabledFlag() ? pcSlice->getNumEntryPointOffsets()+1 : pcSlice->getPPS()->getNumSubstreams();
 
  // init each couple {EntropyDecoder, Substream}
  UInt *puiSubstreamSizes = pcSlice->getSubstreamSizes();
 
  ppcSubstreams    = new TComInputBitstream*[uiNumSubstreams];
  m_pcSbacDecoders = new TDecSbac[uiNumSubstreams];
  m_pcBinCABACs    = new TDecBinCABAC[uiNumSubstreams];
  for ( UInt ui = 0 ; ui < uiNumSubstreams ; ui++ )
  {
    m_pcSbacDecoders[ui].init(&m_pcBinCABACs[ui]);
    ppcSubstreams[ui] = pcBitstream->extractSubstream(ui+1 < uiNumSubstreams ? puiSubstreamSizes[ui] : pcBitstream->getNumBitsLeft());
	//printf("%c ",  ppcSubstreams[ui]);
  }

  for ( UInt ui = 0 ; ui+1 < uiNumSubstreams; ui++ )
  {
    m_pcEntropyDecoder->setEntropyDecoder ( &m_pcSbacDecoders[uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->setBitstream      (  ppcSubstreams   [uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->resetEntropy      (pcSlice);
  }

  m_pcEntropyDecoder->setEntropyDecoder ( m_pcSbacDecoder  );
  m_pcEntropyDecoder->setBitstream      ( ppcSubstreams[0] );
  m_pcEntropyDecoder->resetEntropy      (pcSlice);

  m_pcSbacDecoders[0].load(m_pcSbacDecoder);

  




  m_pcSliceDecoder->decompressSlice( ppcSubstreams, rpcPic, m_pcSbacDecoder, m_pcSbacDecoders);
  m_pcEntropyDecoder->setBitstream(  ppcSubstreams[uiNumSubstreams-1] );
  // deallocate all created substreams, including internal buffers.
  for (UInt ui = 0; ui < uiNumSubstreams; ui++)
  {
    ppcSubstreams[ui]->deleteFifo();
    delete ppcSubstreams[ui];
  }
  delete[] ppcSubstreams;
  delete[] m_pcSbacDecoders; m_pcSbacDecoders = NULL;
  delete[] m_pcBinCABACs; m_pcBinCABACs = NULL;
  
  

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
}

Void TDecGop::filterPicture(TComPic*& rpcPic)
{ TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());
  TComDataCU* CU;

//  sprintf(filename,"F:\\fixation maps\\sigma\\%.1f\\drive\\%d.txt",((float)numm)/10.0, pcSlice->getPOC()+1);
//  ofstream myfile;
//  myfile.open(filename);

 if( pcSlice->getPOC() % 8 == 0)
 {


  TDecCu DecCu;
  int a = 0;
  int b = 0;
  int m = 0;
  int t = 0;
  float w1 = 0.171703; float w2 = 0.121334; float w3 = 0.085740;
  for(UInt kk = 0; kk < 19; kk ++)
  {
     for(UInt ii = 0; ii < 32; ii ++)
	 {
	    if((kk == 0)||(ii == 0)||(kk == 18)||(ii == 31))
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = 0;   
		}
		else
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = TDecCu::bits[TDecCu::uiPoc][b]; b++; 
		}
	 }
  }
  for(UInt kk = 1; kk < 18; kk ++)
  {
     for(UInt ii = 1; ii < 31; ii ++)
	 {
	    m = TDecCu::ctr[TDecCu::uiPoc][kk][ii]*w1   
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])*w2
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])*w3;

		TDecCu::ctrr[TDecCu::uiPoc][kk][ii] = sqrt(pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii])-m),2)*w1   
			+ w2 * (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii-1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])-m),2))
			+ w3* (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii+1])-m),2)));

		TDecCu::ctr2[TDecCu::uiPoc][t] = TDecCu::ctrr[TDecCu::uiPoc][kk][ii];   
		TDecCu::ww[TDecCu::uiPoc][t] = TDecCu::ctr2[TDecCu::uiPoc][t];
		t++;
	 }
  }

  for(UInt xx = 0; xx < TDecCu::LCUs; xx++)
  {
    TDecCu::bits[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx] * w[xx];  
	TDecCu::www[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx];
  }

  DecCu.quicksort(TDecCu::ww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
  DecCu.quicksort(TDecCu::www[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
 
  for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
      TDecCu::ctr2[TDecCu::uiPoc][yy] = TDecCu::ctr2[TDecCu::uiPoc][yy]/(TDecCu::ww[TDecCu::uiPoc][TDecCu::LCUs - 1]);  
	  TDecCu::bits[TDecCu::uiPoc][yy] = TDecCu::bits[TDecCu::uiPoc][yy]/(TDecCu::www[TDecCu::uiPoc][TDecCu::LCUs - 1]);

	  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits[TDecCu::uiPoc][yy] + TDecCu::ctr2[TDecCu::uiPoc][yy])/2 ; 
	  
	   TDecCu::wwww[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];
  }
  DecCu.quicksort(TDecCu::wwww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits_ctr[TDecCu::uiPoc][yy]-TDecCu::wwww[TDecCu::uiPoc][0])/(TDecCu::wwww[TDecCu::uiPoc][TDecCu::LCUs - 1]-TDecCu::wwww[TDecCu::uiPoc][0]);
     
  TDecCu::sortbits[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];

 
 } 
DecCu.quicksort(TDecCu::sortbits[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1)); 
}

cc = (pcSlice->isIntra() ? 1 : 0);
  
  // deblocking filter
if (target == 0)
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic( rpcPic);
}
else if( (QP == 22 && target <= 13) || (QP == 27 && target <= 14) || (QP == 32 && target <= 15) || (QP == 37 && target <=15) )
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic_sgcc( rpcPic, target, a, b, cc );
}



  if( pcSlice->getSPS()->getUseSAO() )
  {
    m_pcSAO->reconstructBlkSAOParams(rpcPic, rpcPic->getPicSym()->getSAOBlkParam());
    m_pcSAO->SAOProcess(rpcPic);
    m_pcSAO->PCMLFDisableProcess(rpcPic);
  }

  rpcPic->compressMotion();
 /*Char c = (pcSlice->isIntra() ? 'I' : pcSlice->isInterP() ? 'P' : 'B');
  if (!pcSlice->isReferenced()) c += 32;

  //-- For time output for each slice
  printf("POC %4d TId: %1d ( %c-SLICE, QP%3d ) ", pcSlice->getPOC(),
                                                  pcSlice->getTLayer(),
                                                  c,
                                                  pcSlice->getSliceQp() );

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
  printf ("[DT %6.3f] ", m_dDecTime );
  m_dDecTime  = 0;

  for (Int iRefList = 0; iRefList < 2; iRefList++)
  {
    printf ("[L%d ", iRefList);
    for (Int iRefIndex = 0; iRefIndex < pcSlice->getNumRefIdx(RefPicList(iRefList)); iRefIndex++)
    {
      printf ("%d ", pcSlice->getRefPOC(RefPicList(iRefList), iRefIndex));
    }
    printf ("] ");
  }
  if (m_decodedPictureHashSEIEnabled)
  {
    SEIMessages pictureHashes = getSeisByType(rpcPic->getSEIs(), SEI::DECODED_PICTURE_HASH );
    const SEIDecodedPictureHash *hash = ( pictureHashes.size() > 0 ) ? (SEIDecodedPictureHash*) *(pictureHashes.begin()) : NULL;
    if (pictureHashes.size() > 1)
    {
      printf ("Warning: Got multiple decoded picture hash SEI messages. Using first.");
    }
    calcAndPrintHashStatus(*rpcPic->getPicYuvRec(), hash);
  }

  printf("\n");*/

#if SETTING_PIC_OUTPUT_MARK
  rpcPic->setOutputMark(rpcPic->getSlice(0)->getPicOutputFlag() ? true : false);
#else
  rpcPic->setOutputMark(true);
#endif
  rpcPic->setReconMark(true);
}

//yangren
void TDecCu::swap(float *list, int low, int high )
{    
	float temp = list[low];
	list[low] = list[high];
	list[high] = temp;
}

void TDecCu::quicksort(float *list, int low, int high)
{   
	float pivot = list[ (low + high) / 2 ];
	int left = low - 1;
	int right = high;

	if(low >= high) 
		return;

	swap(list, (low + high) / 2, high);          
	do     
	{
		while(list[++left] < pivot);         
		while(right != 0 && list[--right] > pivot);         
		swap(list, left, right);     
	} while (left < right);          

	swap(list, left, right);     
	swap(list, left, high);          

	quicksort(list, low, left - 1);     
	quicksort(list, left + 1, high); 
}
//yangren end

/**
 * Calculate and print hash for pic, compare to picture_digest SEI if
 * present in seis.  seis may be NULL.  Hash is printed to stdout, in
 * a manner suitable for the status line. Theformat is:
 *  [Hash_type:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,(yyy)]
 * Where, x..x is the hash
 *        yyy has the following meanings:
 *            OK          - calculated hash matches the SEI message
 *            ***ERROR*** - calculated hash does not match the SEI message
 *            unk         - no SEI message was available for comparison
 */
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI)
{
  /* calculate MD5sum for entire reconstructed picture */
  TComDigest recon_digest;
  Int numChar=0;
  const Char* hashType = "\0";

  if (pictureHashSEI)
  {
    switch (pictureHashSEI->method)
    {
      case SEIDecodedPictureHash::MD5:
        {
          hashType = "MD5";
          numChar = calcMD5(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CRC:
        {
          hashType = "CRC";
          numChar = calcCRC(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CHECKSUM:
        {
          hashType = "Checksum";
          numChar = calcChecksum(pic, recon_digest);
          break;
        }
      default:
        {
          assert (!"unknown hash type");
          break;
        }
    }
  }

  /* compare digest against received version */
  const Char* ok = "(unk)";
  Bool mismatch = false;

  if (pictureHashSEI)
  {
    ok = "(OK)";
    if (recon_digest != pictureHashSEI->m_digest)
    {
      ok = "(***ERROR***)";
      mismatch = true;
    }
  }

  printf("[%s:%s,%s] ", hashType, digestToString(recon_digest, numChar).c_str(), ok);

  if (mismatch)
  {
    g_md5_mismatch = true;
    printf("[rx%s:%s] ", hashType, digestToString(pictureHashSEI->m_digest, numChar).c_str());
  }
}
//! \}
