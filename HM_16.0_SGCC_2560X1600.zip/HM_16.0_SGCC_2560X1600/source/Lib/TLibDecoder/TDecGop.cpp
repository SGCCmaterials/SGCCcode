/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TDecGop.cpp
    \brief    GOP decoder class
*/

#include "TDecGop.h"
#include "TDecCAVLC.h"
#include "TDecSbac.h"
#include "TDecBinCoder.h"
#include "TDecBinCoderCABAC.h"
#include "libmd5/MD5.h"
#include "TLibCommon/SEI.h"
#include "TLibCommon/TComDataCU.h"
#include <time.h>
#include "TDecCu.h"
#include "math.h" 
#include <algorithm>
#include "Windows.h"
#include <fstream>
char filename[1315];
extern UInt target;
extern UInt numm;
UInt QP,cc;
UInt N3, N2, N1;
float b, a;

UInt table_N3_22[9] = {18,30,41,53,77,115,157,442,727};
UInt table_N2_22[9] = {120,197,273,350,510,757,1000,1000,1000};
UInt table_N1_22[9] = {310,506,704,899,1000,1000,1000,1000,1000};

UInt table_N3_27[15] = {14,22,30,37,45,53,65,91,116,141,266,458,650,843,1000};
UInt table_N2_27[15] = {92,144,195,247,299,350,432,598,765,933,1000,1000,1000,1000,1000};
UInt table_N1_27[15] = {237,369,502,636,768,901,1000,1000,1000,1000,1000,1000,1000,1000,1000};

UInt table_N3_32[19] = {10,16,22,28,34,40,47,53,59,79,98,118,138,197,348,498,649,799,949};
UInt table_N2_32[19] = {65,106,146,186,227,267,307,348,388,517,648,779,909,1000,1000,1000,1000,1000,1000};
UInt table_N1_32[19] = {168,271,375,480,583,687,791,894,999,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000};

UInt table_N3_37[24] = {7,12,18,23,28,33,38,43,48,54,59,75,92,108,125,141,200,326,453,579,705,831,958,1000};
UInt table_N2_37[24] = {48,82,116,150,184,218,252,286,320,353,387,494,603,713,822,933,1000,1000,1000,1000,1000,1000,1000,1000};
UInt table_N1_37[24] = {125,212,298,386,473,560,647,735,822,909,996,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000};


extern Bool g_md5_mismatch; ///< top level flag to signal when there is a decode problem

float w[1000] = {0.029158,0.064944,0.100066,0.135189,0.168986,0.202121,0.234592,0.265739,0.295560,0.324056,0.351226,0.376408,0.400265,0.421471,0.440689,0.456594,0.469848,0.480451,0.487740,0.491054,0.491054,0.487740,0.480451,0.469848,0.456594,0.440689,0.421471,0.400265,0.376408,0.351226,0.324056,0.295560,0.265739,0.234592,0.202121,0.168986,0.135189,0.100066,0.064944,0.029158,0.051027,0.087475,0.123923,0.159046,0.194168,0.228628,0.261763,0.294235,0.325381,0.355202,0.383698,0.410868,0.435388,0.458582,0.478463,0.496355,0.510934,0.522200,0.529490,0.533466,0.533466,0.529490,0.522200,0.510934,0.496355,0.478463,0.458582,0.435388,0.410868,0.383698,0.355202,0.325381,0.294235,0.261763,0.228628,0.194168,0.159046,0.123923,0.087475,0.051027,0.070908,0.108681,0.145792,0.182240,0.218025,0.253148,0.287608,0.321405,0.353877,0.385023,0.415507,0.444003,0.469848,0.494367,0.516236,0.535454,0.550696,0.563287,0.571239,0.575878,0.575878,0.571239,0.563287,0.550696,0.535454,0.516236,0.494367,0.469848,0.444003,0.415507,0.385023,0.353877,0.321405,0.287608,0.253148,0.218025,0.182240,0.145792,0.108681,0.070908,0.089463,0.127899,0.165673,0.203446,0.239894,0.276342,0.312127,0.347250,0.381047,0.413519,0.445328,0.475149,0.503645,0.529490,0.552684,0.573890,0.590457,0.604374,0.613651,0.618290,0.618290,0.613651,0.604374,0.590457,0.573890,0.552684,0.529490,0.503645,0.475149,0.445328,0.413519,0.381047,0.347250,0.312127,0.276342,0.239894,0.203446,0.165673,0.127899,0.089463,0.106693,0.145792,0.184228,0.222664,0.260437,0.298211,0.334659,0.371107,0.406229,0.440689,0.473824,0.504970,0.535454,0.563287,0.588469,0.611001,0.630219,0.644798,0.655401,0.660702,0.660702,0.655401,0.644798,0.630219,0.611001,0.588469,0.563287,0.535454,0.504970,0.473824,0.440689,0.406229,0.371107,0.334659,0.298211,0.260437,0.222664,0.184228,0.145792,0.106693,0.121935,0.161696,0.200795,0.239894,0.278993,0.317429,0.355202,0.392975,0.429423,0.465209,0.499669,0.533466,0.565275,0.595096,0.622929,0.647449,0.668655,0.685222,0.696488,0.702452,0.702452,0.696488,0.685222,0.668655,0.647449,0.622929,0.595096,0.565275,0.533466,0.499669,0.465209,0.429423,0.392975,0.355202,0.317429,0.278993,0.239894,0.200795,0.161696,0.121935,0.135189,0.175613,0.215374,0.255799,0.295560,0.334659,0.373757,0.412194,0.449967,0.487740,0.523526,0.559311,0.593108,0.624917,0.655401,0.681909,0.705765,0.724321,0.738237,0.744864,0.744864,0.738237,0.724321,0.705765,0.681909,0.655401,0.624917,0.593108,0.559311,0.523526,0.487740,0.449967,0.412194,0.373757,0.334659,0.295560,0.255799,0.215374,0.175613,0.135189,0.146455,0.187541,0.228628,0.269052,0.309476,0.349901,0.389662,0.429423,0.468522,0.506958,0.544732,0.581842,0.618290,0.652750,0.685222,0.715043,0.741551,0.763419,0.778661,0.787276,0.787276,0.778661,0.763419,0.741551,0.715043,0.685222,0.652750,0.618290,0.581842,0.544732,0.506958,0.468522,0.429423,0.389662,0.349901,0.309476,0.269052,0.228628,0.187541,0.146455,0.156395,0.197482,0.239231,0.280318,0.321405,0.362492,0.402916,0.444003,0.483764,0.523526,0.563287,0.601723,0.639496,0.676607,0.711730,0.744864,0.774685,0.800530,0.819085,0.829689,0.829689,0.819085,0.800530,0.774685,0.744864,0.711730,0.676607,0.639496,0.601723,0.563287,0.523526,0.483764,0.444003,0.402916,0.362492,0.321405,0.280318,0.239231,0.197482,0.156395,0.163685,0.205434,0.247184,0.288933,0.330683,0.372432,0.413519,0.455268,0.496355,0.537442,0.577866,0.618290,0.658052,0.696488,0.734924,0.770709,0.804506,0.834990,0.858184,0.871438,0.871438,0.858184,0.834990,0.804506,0.770709,0.734924,0.696488,0.658052,0.618290,0.577866,0.537442,0.496355,0.455268,0.413519,0.372432,0.330683,0.288933,0.247184,0.205434,0.163685,0.168986,0.211398,0.253148,0.295560,0.337309,0.379722,0.421471,0.463221,0.504970,0.546720,0.588469,0.630219,0.671306,0.711730,0.752154,0.791252,0.829689,0.864811,0.893970,0.913188,0.913188,0.893970,0.864811,0.829689,0.791252,0.752154,0.711730,0.671306,0.630219,0.588469,0.546720,0.504970,0.463221,0.421471,0.379722,0.337309,0.295560,0.253148,0.211398,0.168986,0.172300,0.214712,0.257124,0.299536,0.341286,0.383698,0.426110,0.468522,0.510934,0.552684,0.595096,0.637508,0.679258,0.721670,0.763419,0.804506,0.846256,0.886017,0.923791,0.952949,0.952949,0.923791,0.886017,0.846256,0.804506,0.763419,0.721670,0.679258,0.637508,0.595096,0.552684,0.510934,0.468522,0.426110,0.383698,0.341286,0.299536,0.257124,0.214712,0.172300,0.172962,0.215374,0.257787,0.300199,0.342611,0.385023,0.427435,0.469848,0.512260,0.554672,0.597084,0.639496,0.681909,0.724321,0.766733,0.809145,0.851557,0.893970,0.936382,0.978794,0.978794,0.936382,0.893970,0.851557,0.809145,0.766733,0.724321,0.681909,0.639496,0.597084,0.554672,0.512260,0.469848,0.427435,0.385023,0.342611,0.300199,0.257787,0.215374,0.172962,0.172300,0.214712,0.257124,0.299536,0.341286,0.383698,0.426110,0.468522,0.510934,0.552684,0.595096,0.637508,0.679258,0.721670,0.763419,0.804506,0.846256,0.886017,0.923791,0.952949,0.952949,0.923791,0.886017,0.846256,0.804506,0.763419,0.721670,0.679258,0.637508,0.595096,0.552684,0.510934,0.468522,0.426110,0.383698,0.341286,0.299536,0.257124,0.214712,0.172300,0.168986,0.211398,0.253148,0.295560,0.337309,0.379722,0.421471,0.463221,0.504970,0.546720,0.588469,0.630219,0.671306,0.711730,0.752154,0.791252,0.829689,0.864811,0.893970,0.913188,0.913188,0.893970,0.864811,0.829689,0.791252,0.752154,0.711730,0.671306,0.630219,0.588469,0.546720,0.504970,0.463221,0.421471,0.379722,0.337309,0.295560,0.253148,0.211398,0.168986,0.163685,0.205434,0.247184,0.288933,0.330683,0.372432,0.413519,0.455268,0.496355,0.537442,0.577866,0.618290,0.658052,0.696488,0.734924,0.770709,0.804506,0.834990,0.858184,0.871438,0.871438,0.858184,0.834990,0.804506,0.770709,0.734924,0.696488,0.658052,0.618290,0.577866,0.537442,0.496355,0.455268,0.413519,0.372432,0.330683,0.288933,0.247184,0.205434,0.163685,0.156395,0.197482,0.239231,0.280318,0.321405,0.362492,0.402916,0.444003,0.483764,0.523526,0.563287,0.601723,0.639496,0.676607,0.711730,0.744864,0.774685,0.800530,0.819085,0.829689,0.829689,0.819085,0.800530,0.774685,0.744864,0.711730,0.676607,0.639496,0.601723,0.563287,0.523526,0.483764,0.444003,0.402916,0.362492,0.321405,0.280318,0.239231,0.197482,0.156395,0.146455,0.187541,0.228628,0.269052,0.309476,0.349901,0.389662,0.429423,0.468522,0.506958,0.544732,0.581842,0.618290,0.652750,0.685222,0.715043,0.741551,0.763419,0.778661,0.787276,0.787276,0.778661,0.763419,0.741551,0.715043,0.685222,0.652750,0.618290,0.581842,0.544732,0.506958,0.468522,0.429423,0.389662,0.349901,0.309476,0.269052,0.228628,0.187541,0.146455,0.135189,0.175613,0.215374,0.255799,0.295560,0.334659,0.373757,0.412194,0.449967,0.487740,0.523526,0.559311,0.593108,0.624917,0.655401,0.681909,0.705765,0.724321,0.738237,0.744864,0.744864,0.738237,0.724321,0.705765,0.681909,0.655401,0.624917,0.593108,0.559311,0.523526,0.487740,0.449967,0.412194,0.373757,0.334659,0.295560,0.255799,0.215374,0.175613,0.135189,0.121935,0.161696,0.200795,0.239894,0.278993,0.317429,0.355202,0.392975,0.429423,0.465209,0.499669,0.533466,0.565275,0.595096,0.622929,0.647449,0.668655,0.685222,0.696488,0.702452,0.702452,0.696488,0.685222,0.668655,0.647449,0.622929,0.595096,0.565275,0.533466,0.499669,0.465209,0.429423,0.392975,0.355202,0.317429,0.278993,0.239894,0.200795,0.161696,0.121935,0.106693,0.145792,0.184228,0.222664,0.260437,0.298211,0.334659,0.371107,0.406229,0.440689,0.473824,0.504970,0.535454,0.563287,0.588469,0.611001,0.630219,0.644798,0.655401,0.660702,0.660702,0.655401,0.644798,0.630219,0.611001,0.588469,0.563287,0.535454,0.504970,0.473824,0.440689,0.406229,0.371107,0.334659,0.298211,0.260437,0.222664,0.184228,0.145792,0.106693,0.089463,0.127899,0.165673,0.203446,0.239894,0.276342,0.312127,0.347250,0.381047,0.413519,0.445328,0.475149,0.503645,0.529490,0.552684,0.573890,0.590457,0.604374,0.613651,0.618290,0.618290,0.613651,0.604374,0.590457,0.573890,0.552684,0.529490,0.503645,0.475149,0.445328,0.413519,0.381047,0.347250,0.312127,0.276342,0.239894,0.203446,0.165673,0.127899,0.089463,0.070908,0.108681,0.145792,0.182240,0.218025,0.253148,0.287608,0.321405,0.353877,0.385023,0.415507,0.444003,0.469848,0.494367,0.516236,0.535454,0.550696,0.563287,0.571239,0.575878,0.575878,0.571239,0.563287,0.550696,0.535454,0.516236,0.494367,0.469848,0.444003,0.415507,0.385023,0.353877,0.321405,0.287608,0.253148,0.218025,0.182240,0.145792,0.108681,0.070908,0.051027,0.087475,0.123923,0.159046,0.194168,0.228628,0.261763,0.294235,0.325381,0.355202,0.383698,0.410868,0.435388,0.458582,0.478463,0.496355,0.510934,0.522200,0.529490,0.533466,0.533466,0.529490,0.522200,0.510934,0.496355,0.478463,0.458582,0.435388,0.410868,0.383698,0.355202,0.325381,0.294235,0.261763,0.228628,0.194168,0.159046,0.123923,0.087475,0.051027,0.029158,0.064944,0.100066,0.135189,0.168986,0.202121,0.234592,0.265739,0.295560,0.324056,0.351226,0.376408,0.400265,0.421471,0.440689,0.456594,0.469848,0.480451,0.487740,0.491054,0.491054,0.487740,0.480451,0.469848,0.456594,0.440689,0.421471,0.400265,0.376408,0.351226,0.324056,0.295560,0.265739,0.234592,0.202121,0.168986,0.135189,0.100066,0.064944,0.029158};
float TDecCu::ctr[TDecCu::frames][27][42] = {0};
float TDecCu::ctr2[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::ctrr[TDecCu::frames][TDecCu::LCUs][42] = {0};
float TDecCu::ww[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::www[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::wwww[TDecCu::frames][TDecCu::LCUs] = {0};
//! \ingroup TLibDecoder
//! \{
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI);
// ====================================================================================================================
// Constructor / destructor / initialization / destroy
// ====================================================================================================================

TDecGop::TDecGop()
{
  m_dDecTime = 0;
  m_pcSbacDecoders = NULL;
  m_pcBinCABACs = NULL;
}

TDecGop::~TDecGop()
{

}

Void TDecGop::create()
{

}


Void TDecGop::destroy()
{
}

Void TDecGop::init( TDecEntropy*            pcEntropyDecoder,
                   TDecSbac*               pcSbacDecoder,
                   TDecBinCABAC*           pcBinCABAC,
                   TDecCavlc*              pcCavlcDecoder,
                   TDecSlice*              pcSliceDecoder,
                   TComLoopFilter*         pcLoopFilter,
                   TComSampleAdaptiveOffset* pcSAO
                   )
{
  m_pcEntropyDecoder      = pcEntropyDecoder;
  m_pcSbacDecoder         = pcSbacDecoder;
  m_pcBinCABAC            = pcBinCABAC;
  m_pcCavlcDecoder        = pcCavlcDecoder;
  m_pcSliceDecoder        = pcSliceDecoder;
  m_pcLoopFilter          = pcLoopFilter;
  m_pcSAO  = pcSAO;
}


// ====================================================================================================================
// Private member functions
// ====================================================================================================================
// ====================================================================================================================
// Public member functions
// ====================================================================================================================

Void TDecGop::decompressSlice(TComInputBitstream* pcBitstream, TComPic*& rpcPic)
{

  TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());

  UInt QP_o = pcSlice->getSliceQp();

  if(QP_o < 27) QP = 22;
  else if ( QP_o >= 27 && QP_o < 32) QP = 27;
  else if ( QP_o >= 32 && QP_o < 36) QP = 32;
  else if ( QP_o >= 37) QP = 37;

  if(QP == 22) { a = 0.3041, b = 0.0255;}
  if(QP == 27) { a = 0.3874, b = 0.0433;}
  if(QP == 32) { a = 0.4101, b = 0.0459;}
  if(QP == 37) { a = 0.4347, b = 0.0576;}

   if(QP ==22)
  {
     if(target>=15 && target<=23)
	 {
		 N3 = table_N3_22[target-15]; N2 = table_N2_22[target-15]; N1 = table_N1_22[target-15];
	 } 
	 else if(target > 23)
     {
		 N3 = table_N3_22[8]; N2 = table_N2_22[8]; N1 = table_N1_22[8];
	 }
  }

  if(QP ==27)
  {
     if(target>=16 && target<=30)
	 {
		 N3 = table_N3_27[target-16]; N2 = table_N2_27[target-16]; N1 = table_N1_27[target-16];
	 } 
	 else if(target>=30)
	 {
		 N3 = table_N3_27[14]; N2 = table_N2_27[14]; N1 = table_N1_27[14];
	 } 
  }

  if(QP ==32)
  {
     if(target>=17 && target <= 35)
	 {
		 N3 = table_N3_32[target-17]; N2 = table_N2_32[target-17]; N1 = table_N1_32[target-17];
	 } 
	 else if(target>=35)
	 {
		 N3 = table_N3_32[18]; N2 = table_N2_32[18]; N1 = table_N1_32[18];
	 } 
  }

  if(QP ==37)
  {
     if(target>=17 && target<=40)
	 {
		 N3 = table_N3_37[target-17]; N2 = table_N2_37[target-17]; N1 = table_N1_37[target-17];
	 } 
	 else if(target>=40)
	 {
		 N3 = table_N3_37[23]; N2 = table_N2_37[23]; N1 = table_N1_37[23];
	 } 
  }




  // Table of extracted substreams.
  // These must be deallocated AND their internal fifos, too.
  TComInputBitstream **ppcSubstreams = NULL;
  TDecCu::uiPoc = pcSlice->getPOC();//yangren begin
  //-- For time output for each slice
//  clock_t iBeforeTime = clock();
  m_pcSbacDecoder->init( (TDecBinIf*)m_pcBinCABAC );
  m_pcEntropyDecoder->setEntropyDecoder (m_pcSbacDecoder);

  UInt uiNumSubstreams = pcSlice->getPPS()->getEntropyCodingSyncEnabledFlag() ? pcSlice->getNumEntryPointOffsets()+1 : pcSlice->getPPS()->getNumSubstreams();
 
  // init each couple {EntropyDecoder, Substream}
  UInt *puiSubstreamSizes = pcSlice->getSubstreamSizes();
 
  ppcSubstreams    = new TComInputBitstream*[uiNumSubstreams];
  m_pcSbacDecoders = new TDecSbac[uiNumSubstreams];
  m_pcBinCABACs    = new TDecBinCABAC[uiNumSubstreams];
  for ( UInt ui = 0 ; ui < uiNumSubstreams ; ui++ )
  {
    m_pcSbacDecoders[ui].init(&m_pcBinCABACs[ui]);
    ppcSubstreams[ui] = pcBitstream->extractSubstream(ui+1 < uiNumSubstreams ? puiSubstreamSizes[ui] : pcBitstream->getNumBitsLeft());
	//printf("%c ",  ppcSubstreams[ui]);
  }

  for ( UInt ui = 0 ; ui+1 < uiNumSubstreams; ui++ )
  {
    m_pcEntropyDecoder->setEntropyDecoder ( &m_pcSbacDecoders[uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->setBitstream      (  ppcSubstreams   [uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->resetEntropy      (pcSlice);
  }

  m_pcEntropyDecoder->setEntropyDecoder ( m_pcSbacDecoder  );
  m_pcEntropyDecoder->setBitstream      ( ppcSubstreams[0] );
  m_pcEntropyDecoder->resetEntropy      (pcSlice);

  m_pcSbacDecoders[0].load(m_pcSbacDecoder);

  




  m_pcSliceDecoder->decompressSlice( ppcSubstreams, rpcPic, m_pcSbacDecoder, m_pcSbacDecoders);
  m_pcEntropyDecoder->setBitstream(  ppcSubstreams[uiNumSubstreams-1] );
  // deallocate all created substreams, including internal buffers.
  for (UInt ui = 0; ui < uiNumSubstreams; ui++)
  {
    ppcSubstreams[ui]->deleteFifo();
    delete ppcSubstreams[ui];
  }
  delete[] ppcSubstreams;
  delete[] m_pcSbacDecoders; m_pcSbacDecoders = NULL;
  delete[] m_pcBinCABACs; m_pcBinCABACs = NULL;
  
  

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
}

Void TDecGop::filterPicture(TComPic*& rpcPic)
{ TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());
  TComDataCU* CU;

/* sprintf(filename,"F:\\fixation maps\\sigma\\%.1f\\traffic\\%d.txt",((float)numm)/10.0, pcSlice->getPOC()+1);
  ofstream myfile;
  myfile.open(filename);
*/
 if( pcSlice->getPOC() % 8 == 0)
 {
 
  TDecCu DecCu;
  int a = 0;
  int b = 0;
  int m = 0;
  int t = 0;
  float w1 = 0.171703; float w2 = 0.121334; float w3 = 0.085740;
 /* float w1 = 1; float w2, w3;

  if(numm == 6) {w2 =0.2494;  w3 =0.0622;}
  if(numm == 12) {w2 =0.7066;  w3 =0.4994;}
  if(numm == 18) {w2 =0.8570;  w3 =0.7344;}
  if(numm == 24) {w2 =0.9169;  w3 =0.8406;}
  if(numm == 30) {w2 =0.9460;  w3 =0.8948;}
  if(numm == 36) {w2 =0.9622;  w3 =0.9257;}
  if(numm == 42) {w2 =0.9721;  w3 =0.9449;}
  if(numm == 48) {w2 =0.9785;  w3 =0.9575;}
  if(numm == 54) {w2 =0.9830;  w3 =0.9663;}
  if(numm == 60) {w2 =0.9862;  w3 =0.9726;}*/


  for(UInt kk = 0; kk < 27; kk ++)
  {
     for(UInt ii = 0; ii < 42; ii ++)
	 {
	    if((kk == 0)||(ii == 0)||(kk == 26)||(ii == 41))
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = 0;   
		}
		else
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = TDecCu::bits[TDecCu::uiPoc][b]; b++;  
		}
	 }
  }
  for(UInt kk = 1; kk < 26; kk ++)
  {
     for(UInt ii = 1; ii < 41; ii ++)
	 {
	    m = TDecCu::ctr[TDecCu::uiPoc][kk][ii]*w1   
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])*w2
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])*w3;

		TDecCu::ctrr[TDecCu::uiPoc][kk][ii] = sqrt(pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii])-m),2)*w1  
			+ w2 * (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii-1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])-m),2))
			+ w3* (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii+1])-m),2)));

		TDecCu::ctr2[TDecCu::uiPoc][t] = TDecCu::ctrr[TDecCu::uiPoc][kk][ii];  
		TDecCu::ww[TDecCu::uiPoc][t] = TDecCu::ctr2[TDecCu::uiPoc][t];
		t++;
	 }
  }

  for(UInt xx = 0; xx < TDecCu::LCUs; xx++)
  {
    TDecCu::bits[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx] * w[xx];  
	TDecCu::www[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx];
  }

  DecCu.quicksort(TDecCu::ww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
  DecCu.quicksort(TDecCu::www[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
 
  for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
      TDecCu::ctr2[TDecCu::uiPoc][yy] = TDecCu::ctr2[TDecCu::uiPoc][yy]/(TDecCu::ww[TDecCu::uiPoc][TDecCu::LCUs - 1]);  
	  TDecCu::bits[TDecCu::uiPoc][yy] = TDecCu::bits[TDecCu::uiPoc][yy]/(TDecCu::www[TDecCu::uiPoc][TDecCu::LCUs - 1]);

	  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits[TDecCu::uiPoc][yy] + TDecCu::ctr2[TDecCu::uiPoc][yy])/2 ; 
	  
	   TDecCu::wwww[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];
  }
  DecCu.quicksort(TDecCu::wwww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits_ctr[TDecCu::uiPoc][yy]-TDecCu::wwww[TDecCu::uiPoc][0])/(TDecCu::wwww[TDecCu::uiPoc][TDecCu::LCUs - 1]-TDecCu::wwww[TDecCu::uiPoc][0]);
     
  TDecCu::sortbits[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];
    
  }


  DecCu.quicksort(TDecCu::sortbits[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1)); 

}
 /*  if( TDecCu::uiPoc%32 == 0)
  {
     for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
	 {
		 myfile<<TDecCu::bits_ctr[TDecCu::uiPoc][yy]<<" ";
		 if(((yy+1)%40)==0) myfile<<"\n";
	 }
	  
  }
  else
  {
	   for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
	 {
		 myfile<<TDecCu::bits_ctr[TDecCu::uiPoc-1-(TDecCu::uiPoc-1)%8][yy]<<" ";
		 if(((yy+1)%40)==0) myfile<<"\n";
	 }
  }
	  
  myfile.close();   */
  
 cc = (pcSlice->isIntra() ? 1 : 0);
  // deblocking filter
if (target == 0)
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic( rpcPic);
}
else if( (QP == 22 && target <= 13) || (QP == 27 && target <= 14) || (QP == 32 && target <= 15) || (QP == 37 && target <=15) )
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic_sgcc( rpcPic, target, a, b, cc );
}

  if( pcSlice->getSPS()->getUseSAO() )
  {
    m_pcSAO->reconstructBlkSAOParams(rpcPic, rpcPic->getPicSym()->getSAOBlkParam());
    m_pcSAO->SAOProcess(rpcPic);
    m_pcSAO->PCMLFDisableProcess(rpcPic);
  }

  rpcPic->compressMotion();
 /*Char c = (pcSlice->isIntra() ? 'I' : pcSlice->isInterP() ? 'P' : 'B');
  if (!pcSlice->isReferenced()) c += 32;

  //-- For time output for each slice
  printf("POC %4d TId: %1d ( %c-SLICE, QP%3d ) ", pcSlice->getPOC(),
                                                  pcSlice->getTLayer(),
                                                  c,
                                                  pcSlice->getSliceQp() );

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
  printf ("[DT %6.3f] ", m_dDecTime );
  m_dDecTime  = 0;

  for (Int iRefList = 0; iRefList < 2; iRefList++)
  {
    printf ("[L%d ", iRefList);
    for (Int iRefIndex = 0; iRefIndex < pcSlice->getNumRefIdx(RefPicList(iRefList)); iRefIndex++)
    {
      printf ("%d ", pcSlice->getRefPOC(RefPicList(iRefList), iRefIndex));
    }
    printf ("] ");
  }
  if (m_decodedPictureHashSEIEnabled)
  {
    SEIMessages pictureHashes = getSeisByType(rpcPic->getSEIs(), SEI::DECODED_PICTURE_HASH );
    const SEIDecodedPictureHash *hash = ( pictureHashes.size() > 0 ) ? (SEIDecodedPictureHash*) *(pictureHashes.begin()) : NULL;
    if (pictureHashes.size() > 1)
    {
      printf ("Warning: Got multiple decoded picture hash SEI messages. Using first.");
    }
    calcAndPrintHashStatus(*rpcPic->getPicYuvRec(), hash);
  }

  printf("\n");*/

#if SETTING_PIC_OUTPUT_MARK
  rpcPic->setOutputMark(rpcPic->getSlice(0)->getPicOutputFlag() ? true : false);
#else
  rpcPic->setOutputMark(true);
#endif
  rpcPic->setReconMark(true);
}

//yangren
void TDecCu::swap(float *list, int low, int high )
{    
	float temp = list[low];
	list[low] = list[high];
	list[high] = temp;
}

void TDecCu::quicksort(float *list, int low, int high)
{   
	float pivot = list[ (low + high) / 2 ];
	int left = low - 1;
	int right = high;

	if(low >= high) 
		return;

	swap(list, (low + high) / 2, high);          
	do     
	{
		while(list[++left] < pivot);         
		while(right != 0 && list[--right] > pivot);         
		swap(list, left, right);     
	} while (left < right);          

	swap(list, left, right);     
	swap(list, left, high);          

	quicksort(list, low, left - 1);     
	quicksort(list, left + 1, high); 
}
//yangren end

/**
 * Calculate and print hash for pic, compare to picture_digest SEI if
 * present in seis.  seis may be NULL.  Hash is printed to stdout, in
 * a manner suitable for the status line. Theformat is:
 *  [Hash_type:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,(yyy)]
 * Where, x..x is the hash
 *        yyy has the following meanings:
 *            OK          - calculated hash matches the SEI message
 *            ***ERROR*** - calculated hash does not match the SEI message
 *            unk         - no SEI message was available for comparison
 */
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI)
{
  /* calculate MD5sum for entire reconstructed picture */
  TComDigest recon_digest;
  Int numChar=0;
  const Char* hashType = "\0";

  if (pictureHashSEI)
  {
    switch (pictureHashSEI->method)
    {
      case SEIDecodedPictureHash::MD5:
        {
          hashType = "MD5";
          numChar = calcMD5(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CRC:
        {
          hashType = "CRC";
          numChar = calcCRC(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CHECKSUM:
        {
          hashType = "Checksum";
          numChar = calcChecksum(pic, recon_digest);
          break;
        }
      default:
        {
          assert (!"unknown hash type");
          break;
        }
    }
  }

  /* compare digest against received version */
  const Char* ok = "(unk)";
  Bool mismatch = false;

  if (pictureHashSEI)
  {
    ok = "(OK)";
    if (recon_digest != pictureHashSEI->m_digest)
    {
      ok = "(***ERROR***)";
      mismatch = true;
    }
  }

  printf("[%s:%s,%s] ", hashType, digestToString(recon_digest, numChar).c_str(), ok);

  if (mismatch)
  {
    g_md5_mismatch = true;
    printf("[rx%s:%s] ", hashType, digestToString(pictureHashSEI->m_digest, numChar).c_str());
  }
}
//! \}
