/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TDecGop.cpp
    \brief    GOP decoder class
*/

#include "TDecGop.h"
#include "TDecCAVLC.h"
#include "TDecSbac.h"
#include "TDecBinCoder.h"
#include "TDecBinCoderCABAC.h"
#include "libmd5/MD5.h"
#include "TLibCommon/SEI.h"
#include "TLibCommon/TComDataCU.h"
#include <time.h>
#include "TDecCu.h"
#include "math.h" 
#include <algorithm>
#include <fstream>
#include "Windows.h"

char filename[1315];
extern UInt target, numm;
UInt QP, cc;
UInt N3, N2, N1;
float b, a;

UInt table_N3_22[9] = {1,1,1,2,2,3,5,13,21};
UInt table_N2_22[9] = {3,6,8,10,15,22,28,28,28};
UInt table_N1_22[9] = {9,14,20,25,28,28,28,28,28};

UInt table_N3_27[15] = {0,1,1,1,1,2,2,3,3,4,8,13,19,24,28};
UInt table_N2_27[15] = {3,4,6,7,9,10,12,17,22,27,28,28,28,28,28};
UInt table_N1_27[15] = {7,10,14,18,22,25,28,28,28,28,28,28,28,28,28};

UInt table_N3_32[19] = {0,0,1,1,1,1,1,2,2,2,3,3,4,6,10,14,19,23,27};
UInt table_N2_32[19] = {2,3,4,5,6,8,9,10,11,15,18,23,26,28,28,28,28,28,28};
UInt table_N1_32[19] = {5,8,11,14,17,19,23,25,28,28,28,28,28,28,28,28,28,28,28};

UInt table_N3_37[24] = {0,0,1,1,1,1,1,1,1,2,2,2,3,3,4,4,6,10,13,17,20,24,27,28};
UInt table_N2_37[24] = {2,3,4,5,6,7,8,9,10,11,14,17,20,23,27,28,28,28,28,28,28,28,28,28};
UInt table_N1_37[24] = {4,6,9,11,14,16,19,21,24,25,28,28,28,28,28,28,28,28,28,28,28,28,28,28};


extern Bool g_md5_mismatch; ///< top level flag to signal when there is a decode problem

float w[28] = {0.2837,0.3582,0.3465,0.2567,0.5168,0.6525,0.6311,0.4676,0.7211,0.9105,0.8807,0.6525,0.7708,0.9732,0.9414,0.6975,0.6311,0.7969,0.7708,0.5711,0.3959,0.4998,0.4835,0.3582,0.1902,0.2401,0.2323,0.1721};
float TDecCu::ctr[TDecCu::frames][6][9] = {0};
float TDecCu::ctr2[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::ctrr[TDecCu::frames][TDecCu::LCUs][9] = {0};
float TDecCu::ww[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::www[TDecCu::frames][TDecCu::LCUs] = {0};
float TDecCu::wwww[TDecCu::frames][TDecCu::LCUs] = {0};
//! \ingroup TLibDecoder
//! \{
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI);
// ====================================================================================================================
// Constructor / destructor / initialization / destroy
// ====================================================================================================================

TDecGop::TDecGop()
{
  m_dDecTime = 0;
  m_pcSbacDecoders = NULL;
  m_pcBinCABACs = NULL;
}

TDecGop::~TDecGop()
{

}

Void TDecGop::create()
{

}


Void TDecGop::destroy()
{
}

Void TDecGop::init( TDecEntropy*            pcEntropyDecoder,
                   TDecSbac*               pcSbacDecoder,
                   TDecBinCABAC*           pcBinCABAC,
                   TDecCavlc*              pcCavlcDecoder,
                   TDecSlice*              pcSliceDecoder,
                   TComLoopFilter*         pcLoopFilter,
                   TComSampleAdaptiveOffset* pcSAO
                   )
{
  m_pcEntropyDecoder      = pcEntropyDecoder;
  m_pcSbacDecoder         = pcSbacDecoder;
  m_pcBinCABAC            = pcBinCABAC;
  m_pcCavlcDecoder        = pcCavlcDecoder;
  m_pcSliceDecoder        = pcSliceDecoder;
  m_pcLoopFilter          = pcLoopFilter;
  m_pcSAO  = pcSAO;
}


// ====================================================================================================================
// Private member functions
// ====================================================================================================================
// ====================================================================================================================
// Public member functions
// ====================================================================================================================

Void TDecGop::decompressSlice(TComInputBitstream* pcBitstream, TComPic*& rpcPic)
{

  TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());

  UInt QP_o = pcSlice->getSliceQp();

  if(QP_o < 27) QP = 22;
  else if ( QP_o >= 27 && QP_o < 32) QP = 27;
  else if ( QP_o >= 32 && QP_o < 36) QP = 32;
  else if ( QP_o >= 37) QP = 37;

  if(QP == 22) { a = 0.3041, b = 0.0255;}
  if(QP == 27) { a = 0.3874, b = 0.0433;}
  if(QP == 32) { a = 0.4101, b = 0.0459;}
  if(QP == 37) { a = 0.4347, b = 0.0576;}

   if(QP ==22)
  {
     if(target>=15 && target<=23)
	 {
		 N3 = table_N3_22[target-15]; N2 = table_N2_22[target-15]; N1 = table_N1_22[target-15];
	 } 
	 else if(target > 23)
     {
		 N3 = table_N3_22[8]; N2 = table_N2_22[8]; N1 = table_N1_22[8];
	 }
  }

  if(QP ==27)
  {
     if(target>=16 && target<=30)
	 {
		 N3 = table_N3_27[target-16]; N2 = table_N2_27[target-16]; N1 = table_N1_27[target-16];
	 } 
	 else if(target>=30)
	 {
		 N3 = table_N3_27[14]; N2 = table_N2_27[14]; N1 = table_N1_27[14];
	 } 
  }

  if(QP ==32)
  {
     if(target>=17 && target <= 35)
	 {
		 N3 = table_N3_32[target-17]; N2 = table_N2_32[target-17]; N1 = table_N1_32[target-17];
	 } 
	 else if(target>=35)
	 {
		 N3 = table_N3_32[18]; N2 = table_N2_32[18]; N1 = table_N1_32[18];
	 } 
  }

  if(QP ==37)
  {
     if(target>=17 && target<=40)
	 {
		 N3 = table_N3_37[target-17]; N2 = table_N2_37[target-17]; N1 = table_N1_37[target-17];
	 } 
	 else if(target>=40)
	 {
		 N3 = table_N3_37[23]; N2 = table_N2_37[23]; N1 = table_N1_37[23];
	 } 
  }





  // Table of extracted substreams.
  // These must be deallocated AND their internal fifos, too.
  TComInputBitstream **ppcSubstreams = NULL;
  TDecCu::uiPoc = pcSlice->getPOC();//yangren begin
  //-- For time output for each slice
//  clock_t iBeforeTime = clock();
  m_pcSbacDecoder->init( (TDecBinIf*)m_pcBinCABAC );
  m_pcEntropyDecoder->setEntropyDecoder (m_pcSbacDecoder);

  UInt uiNumSubstreams = pcSlice->getPPS()->getEntropyCodingSyncEnabledFlag() ? pcSlice->getNumEntryPointOffsets()+1 : pcSlice->getPPS()->getNumSubstreams();
 
  // init each couple {EntropyDecoder, Substream}
  UInt *puiSubstreamSizes = pcSlice->getSubstreamSizes();
 
  ppcSubstreams    = new TComInputBitstream*[uiNumSubstreams];
  m_pcSbacDecoders = new TDecSbac[uiNumSubstreams];
  m_pcBinCABACs    = new TDecBinCABAC[uiNumSubstreams];
  for ( UInt ui = 0 ; ui < uiNumSubstreams ; ui++ )
  {
    m_pcSbacDecoders[ui].init(&m_pcBinCABACs[ui]);
    ppcSubstreams[ui] = pcBitstream->extractSubstream(ui+1 < uiNumSubstreams ? puiSubstreamSizes[ui] : pcBitstream->getNumBitsLeft());
	//printf("%c ",  ppcSubstreams[ui]);
  }

  for ( UInt ui = 0 ; ui+1 < uiNumSubstreams; ui++ )
  {
    m_pcEntropyDecoder->setEntropyDecoder ( &m_pcSbacDecoders[uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->setBitstream      (  ppcSubstreams   [uiNumSubstreams - 1 - ui] );
    m_pcEntropyDecoder->resetEntropy      (pcSlice);
  }

  m_pcEntropyDecoder->setEntropyDecoder ( m_pcSbacDecoder  );
  m_pcEntropyDecoder->setBitstream      ( ppcSubstreams[0] );
  m_pcEntropyDecoder->resetEntropy      (pcSlice);

  m_pcSbacDecoders[0].load(m_pcSbacDecoder);
  m_pcSliceDecoder->decompressSlice( ppcSubstreams, rpcPic, m_pcSbacDecoder, m_pcSbacDecoders);
  m_pcEntropyDecoder->setBitstream(  ppcSubstreams[uiNumSubstreams-1] );
  // deallocate all created substreams, including internal buffers.
  for (UInt ui = 0; ui < uiNumSubstreams; ui++)
  {
    ppcSubstreams[ui]->deleteFifo();
    delete ppcSubstreams[ui];
  }
  delete[] ppcSubstreams;
  delete[] m_pcSbacDecoders; m_pcSbacDecoders = NULL;
  delete[] m_pcBinCABACs; m_pcBinCABACs = NULL;
  
  

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
}

Void TDecGop::filterPicture(TComPic*& rpcPic)
{ TComSlice*  pcSlice = rpcPic->getSlice(rpcPic->getCurrSliceIdx());
  TComDataCU* CU;
/*
 sprintf(filename,"F:\\fixation maps\\sigma\\%.1f\\horses240\\%d.txt",((float)numm)/10.0, pcSlice->getPOC()+1);
  ofstream myfile;
  myfile.open(filename);*/

 if( pcSlice->getPOC() % 8 == 0)
 {
 
  TDecCu DecCu;
  int a = 0;
  int b = 0;
  int m = 0;
  int t = 0;
  float w1 = 0.171703; float w2 = 0.121334; float w3 = 0.085740;

  for(UInt kk = 0; kk < 6; kk ++)
  {
     for(UInt ii = 0; ii < 9; ii ++)
	 {
	    if((kk == 0)||(ii == 0)||(kk == 5)||(ii == 8))
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = 0;   
		}
		else
		{
		   TDecCu::ctr[TDecCu::uiPoc][kk][ii] = TDecCu::bits[TDecCu::uiPoc][b]; b++;  
		}
	 }
  }
  for(UInt kk = 1; kk < 5; kk ++)
  {
     for(UInt ii = 1; ii < 8; ii ++)
	 {
	    m = TDecCu::ctr[TDecCu::uiPoc][kk][ii]*w1   
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii]+TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])*w2
			+ (TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1]+TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1]+TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])*w3;

		TDecCu::ctrr[TDecCu::uiPoc][kk][ii] = sqrt(pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii])-m),2)*w1   
			+ w2 * (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii-1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk][ii+1])-m),2))
			+ w3* (pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk-1][ii+1])-m),2)
			+ pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii-1])-m),2)+pow(((TDecCu::ctr[TDecCu::uiPoc][kk+1][ii+1])-m),2)));

		TDecCu::ctr2[TDecCu::uiPoc][t] = TDecCu::ctrr[TDecCu::uiPoc][kk][ii];   
		TDecCu::ww[TDecCu::uiPoc][t] = TDecCu::ctr2[TDecCu::uiPoc][t];
		t++;
	 }
  }

  for(UInt xx = 0; xx < TDecCu::LCUs; xx++)
  {
    TDecCu::bits[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx] * w[xx];  
	TDecCu::www[TDecCu::uiPoc][xx] = TDecCu::bits[TDecCu::uiPoc][xx];
  }

  DecCu.quicksort(TDecCu::ww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
  DecCu.quicksort(TDecCu::www[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
 
  for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
      TDecCu::ctr2[TDecCu::uiPoc][yy] = TDecCu::ctr2[TDecCu::uiPoc][yy]/(TDecCu::ww[TDecCu::uiPoc][TDecCu::LCUs - 1]);  
	  TDecCu::bits[TDecCu::uiPoc][yy] = TDecCu::bits[TDecCu::uiPoc][yy]/(TDecCu::www[TDecCu::uiPoc][TDecCu::LCUs - 1]);

	  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits[TDecCu::uiPoc][yy] + TDecCu::ctr2[TDecCu::uiPoc][yy])/2 ; 
	  
	   TDecCu::wwww[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];
  }
  DecCu.quicksort(TDecCu::wwww[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));
for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
  {
  TDecCu::bits_ctr[TDecCu::uiPoc][yy] = (TDecCu::bits_ctr[TDecCu::uiPoc][yy]-TDecCu::wwww[TDecCu::uiPoc][0])/(TDecCu::wwww[TDecCu::uiPoc][TDecCu::LCUs - 1]-TDecCu::wwww[TDecCu::uiPoc][0]);
     
  TDecCu::sortbits[TDecCu::uiPoc][yy] = TDecCu::bits_ctr[TDecCu::uiPoc][yy];
    
  }
	
  DecCu.quicksort(TDecCu::sortbits[TDecCu::uiPoc], 0, (TDecCu::LCUs - 1));  
  
}
/*
  if( TDecCu::uiPoc%32 == 0)
  {
     for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
	 {
		 myfile<<TDecCu::bits_ctr[TDecCu::uiPoc][yy]<<" ";
		 if(((yy+1)%7)==0) myfile<<"\n";
	 }
	  
  }
  else
  {
	   for(UInt yy = 0; yy < TDecCu::LCUs; yy++)
	 {
		 myfile<<TDecCu::bits_ctr[TDecCu::uiPoc-1-(TDecCu::uiPoc-1)%8][yy]<<" ";
		 if(((yy+1)%7)==0) myfile<<"\n";
	 }
  }
	  
  myfile.close(); */ 

if( pcSlice->isIntra()) cc = 1;
else cc = 0;
// deblocking filter
if (target == 0)
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic( rpcPic);
}
else if( (QP == 22 && target <= 13) || (QP == 27 && target <= 14) || (QP == 32 && target <= 15) || (QP == 37 && target <=15) )
{
  Bool bLFCrossTileBoundary = pcSlice->getPPS()->getLoopFilterAcrossTilesEnabledFlag();
  m_pcLoopFilter->setCfg(bLFCrossTileBoundary);
  m_pcLoopFilter->loopFilterPic_sgcc( rpcPic, target, a, b, cc);
}


  if( pcSlice->getSPS()->getUseSAO() )
  {
    m_pcSAO->reconstructBlkSAOParams(rpcPic, rpcPic->getPicSym()->getSAOBlkParam());
    m_pcSAO->SAOProcess(rpcPic);
    m_pcSAO->PCMLFDisableProcess(rpcPic);
  }

  rpcPic->compressMotion();
/* Char c = (pcSlice->isIntra() ? 'I' : pcSlice->isInterP() ? 'P' : 'B');
  if (!pcSlice->isReferenced()) c += 32;

  //-- For time output for each slice
  printf("POC %4d TId: %1d ( %c-SLICE, QP%3d ) ", pcSlice->getPOC(),
                                                  pcSlice->getTLayer(),
                                                  c,
                                                  pcSlice->getSliceQp() );

//  m_dDecTime += (Double)(clock()-iBeforeTime) / CLOCKS_PER_SEC;
  printf ("[DT %6.3f] ", m_dDecTime );
  m_dDecTime  = 0;

  for (Int iRefList = 0; iRefList < 2; iRefList++)
  {
    printf ("[L%d ", iRefList);
    for (Int iRefIndex = 0; iRefIndex < pcSlice->getNumRefIdx(RefPicList(iRefList)); iRefIndex++)
    {
      printf ("%d ", pcSlice->getRefPOC(RefPicList(iRefList), iRefIndex));
    }
    printf ("] ");
  }
  if (m_decodedPictureHashSEIEnabled)
  {
    SEIMessages pictureHashes = getSeisByType(rpcPic->getSEIs(), SEI::DECODED_PICTURE_HASH );
    const SEIDecodedPictureHash *hash = ( pictureHashes.size() > 0 ) ? (SEIDecodedPictureHash*) *(pictureHashes.begin()) : NULL;
    if (pictureHashes.size() > 1)
    {
      printf ("Warning: Got multiple decoded picture hash SEI messages. Using first.");
    }
    calcAndPrintHashStatus(*rpcPic->getPicYuvRec(), hash);
  }

  printf("\n");*/

#if SETTING_PIC_OUTPUT_MARK
  rpcPic->setOutputMark(rpcPic->getSlice(0)->getPicOutputFlag() ? true : false);
#else
  rpcPic->setOutputMark(true);
#endif
  rpcPic->setReconMark(true);
}

//yangren
void TDecCu::swap(float *list, int low, int high )
{    
	float temp = list[low];
	list[low] = list[high];
	list[high] = temp;
}

void TDecCu::quicksort(float *list, int low, int high)
{   
	float pivot = list[ (low + high) / 2 ];
	int left = low - 1;
	int right = high;

	if(low >= high) 
		return;

	swap(list, (low + high) / 2, high);          
	do     
	{
		while(list[++left] < pivot);         
		while(right != 0 && list[--right] > pivot);         
		swap(list, left, right);     
	} while (left < right);          

	swap(list, left, right);     
	swap(list, left, high);          

	quicksort(list, low, left - 1);     
	quicksort(list, left + 1, high); 
}
//yangren end

/**
 * Calculate and print hash for pic, compare to picture_digest SEI if
 * present in seis.  seis may be NULL.  Hash is printed to stdout, in
 * a manner suitable for the status line. Theformat is:
 *  [Hash_type:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,(yyy)]
 * Where, x..x is the hash
 *        yyy has the following meanings:
 *            OK          - calculated hash matches the SEI message
 *            ***ERROR*** - calculated hash does not match the SEI message
 *            unk         - no SEI message was available for comparison
 */
static Void calcAndPrintHashStatus(TComPicYuv& pic, const SEIDecodedPictureHash* pictureHashSEI)
{
  /* calculate MD5sum for entire reconstructed picture */
  TComDigest recon_digest;
  Int numChar=0;
  const Char* hashType = "\0";

  if (pictureHashSEI)
  {
    switch (pictureHashSEI->method)
    {
      case SEIDecodedPictureHash::MD5:
        {
          hashType = "MD5";
          numChar = calcMD5(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CRC:
        {
          hashType = "CRC";
          numChar = calcCRC(pic, recon_digest);
          break;
        }
      case SEIDecodedPictureHash::CHECKSUM:
        {
          hashType = "Checksum";
          numChar = calcChecksum(pic, recon_digest);
          break;
        }
      default:
        {
          assert (!"unknown hash type");
          break;
        }
    }
  }

  /* compare digest against received version */
  const Char* ok = "(unk)";
  Bool mismatch = false;

  if (pictureHashSEI)
  {
    ok = "(OK)";
    if (recon_digest != pictureHashSEI->m_digest)
    {
      ok = "(***ERROR***)";
      mismatch = true;
    }
  }

  printf("[%s:%s,%s] ", hashType, digestToString(recon_digest, numChar).c_str(), ok);

  if (mismatch)
  {
    g_md5_mismatch = true;
    printf("[rx%s:%s] ", hashType, digestToString(pictureHashSEI->m_digest, numChar).c_str());
  }
}
//! \}
